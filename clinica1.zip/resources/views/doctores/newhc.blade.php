<h2>Vital</h2>
  <div class="form-group">
    <label for="nombre">altura</label>
    <input type="text" class="form-control" name="altura" placeholder="Altura">
    
  </div>
  <div class="form-group">
    <label for="nombre">peso</label>
    <input type="text" class="form-control" name="peso" placeholder="Peso">
    
  </div>
  <div class="form-group">
    <label for="nombre">RH</label>
    <input type="text" class="form-control" name="rh" placeholder="RH">
    
  </div>
  <div class="form-group">
    <label for="nombre">edad</label>
    <input type="text" class="form-control" name="edad" placeholder="edad">
    
  </div>

  <h2>Sintomas</h2>

  <div class="form-group">
    <label for="nombre">Sintoma</label>
    <input type="text" class="form-control" name="sintoma" placeholder="sintoma">
    
  </div>
  <div class="form-group">
    <label for="nombre">descripcion</label>
    <input type="text" class="form-control" name="descripcion" placeholder="descripcion">
    
  </div>

  <h2>Problemas</h2>

  <div class="form-group">
    <label for="nombre">Problemas</label>
    <input type="text" class="form-control" name="problema" placeholder="problema">
    
  </div>
  <div class="form-group">
    <label for="nombre">descripcion</label>
    <input type="text" class="form-control" name="descripcion" placeholder="descripcion">
    
  </div>