<?php $__env->startSection('content'); ?>

<div class="jumbotron jumbotron-fluid">
  <div class="container">
  <?php $__currentLoopData = $vitals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vital): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <p class="lead">Id: <?php echo e($vital->id); ?></p>
  <p class="lead">Altura: <?php echo e($vital->altura); ?></p>
  <p class="lead">Peso: <?php echo e($vital->peso); ?></p>
  <p class="lead">Rh: <?php echo e($vital->rh); ?></p>
  <p class="lead">Edad: <?php echo e($vital->edad); ?></p>
  <p class="lead">Fecha de creación:<?php echo e($vital->created_at); ?></p>
  <p class="lead">Ultima actualización:<?php echo e($vital->updated_at); ?></p>


  <a href="<?php echo e(route('vitals.edit', $vital->id)); ?>"><button type="button" class="btn btn-warning">Editar Vital</button></a>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  <table class="table">

  <thead>
    <tr>
      <th scope="col">ID</th>
      <th scope="col">ENFERMEDAD</th>
      <th scope="col">DESCRIPCIÓN</th>
      <th scope="col">CREACIÓN</th>
      <th scope="col">ACTUALIZACION</th>
      
      
    </tr>
  </thead>
        <tbody>
        <?php $__currentLoopData = $problemas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $problema): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      
             <tr>
                 <th scope="row"><?php echo e($problema->id); ?></th>
                 <td><?php echo e($problema->enfermedad); ?></td>
                 <td><?php echo e($problema->descripcion); ?></td>
                 <td><?php echo e($problema->created_at); ?></td>
                 <td><?php echo e($problema->updated_at); ?></td>
                 
                 <td>
                 
               
                 <a href="<?php echo e(route('problemas.edit', $problema->id)); ?>"><button type="button" class="btn btn-warning">Editar Problema</button></a>
                 
               </td>
               </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  
       </tbody>
</table>
 	<a href="<?php echo e(route('doctores.index')); ?>"><button type="button" class="btn btn-danger">Atras</button></a>
  </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app3', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\clinica1\resources\views/vps/show.blade.php ENDPATH**/ ?>