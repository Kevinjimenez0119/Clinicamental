<?php $__env->startSection('content'); ?>

<?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>
<div style="max-width:600px;margin:0 auto; " class="mt-5 mb-5 card">

<form action="<?php echo e(route('historias.store')); ?>" method="POST">
<?php echo csrf_field(); ?>
<div style="margin:20px;">
<div class="form-group">
    <label for="nombre">medicamentos</label>
    <input type="text" class="form-control" name="medicamentos" placeholder="medicamentos">
    
  </div>
  <div class="form-group">
    <label for="nombre">notas</label>
    <input type="text" class="form-control" name="notas" placeholder="Notas" >
    
  </div>
  <div class="form-group">
    <label for="email">Paciente </label>
    <input type="text" class="form-control" value="<?php echo e($paciente->identificacion); ?>" readonly="readonly", name="id_paciente">
    
  </div>
  
  <div class="form-group">
    <label for="password">tratamientos</label>
    
  </div>
  <h2>Tratamiento</h2>
  <div class="form-group">
    <label for="email">Rol </label>
    <select name="tratamiento" class="form-control" id="rol">
    <?php $__currentLoopData = $tratamientos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tratamiento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <option value="<?php echo e($tratamiento->id); ?>"><?php echo e($tratamiento->tipo_tratamiento); ?></option>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
    
  </div>

  <h2>Vital</h2>
  <div class="form-group">
    <label for="nombre">altura</label>
    <input type="text" class="form-control" name="altura" placeholder="Altura">
    
  </div>
  <div class="form-group">
    <label for="nombre">peso</label>
    <input type="text" class="form-control" name="peso" placeholder="Peso">
    
  </div>
  <div class="form-group">
    <label for="nombre">RH</label>
    <input type="text" class="form-control" name="rh" placeholder="RH">
    
  </div>
  <div class="form-group">
    <label for="nombre">edad</label>
    <input type="text" class="form-control" name="edad" placeholder="edad">
    
  </div>
  <h2>Sintomas</h2>

<div class="form-group">
  <label for="nombre">Sintoma</label>
  <input type="text" class="form-control" name="sintoma" placeholder="sintoma">
  
</div>
<div class="form-group">
  <label for="nombre">descripcion</label>
  <input type="text" class="form-control" name="descripcion" placeholder="descripcion">
  
</div>

<h2>Problemas</h2>

<div class="form-group">
  <label for="nombre">Problemas</label>
  <input type="text" class="form-control" name="problema" placeholder="problema">
  
</div>
<div class="form-group">
  <label for="nombre">descripcion</label>
  <input type="text" class="form-control" name="descripcion" placeholder="descripcion">
  
</div>
  
  
  <button type="submit" class="btn btn-primary">Registrar</button>
  <a href="<?php echo e(route('doctores.index')); ?>"><button type="button" class="btn btn-danger">Cancelar</button></a>
  </div>
</form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\clinica1\resources\views/historias/create.blade.php ENDPATH**/ ?>