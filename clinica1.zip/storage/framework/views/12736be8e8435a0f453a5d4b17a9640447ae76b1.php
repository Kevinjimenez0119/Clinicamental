<?php $__env->startSection('content'); ?>
<?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>
<div style="max-width:600px;margin:0 auto; " class="mt-5 mb-5 card">

<form action="<?php echo e(route('vitals.update', $vital->id)); ?>" method="POST">
<?php echo method_field('PATCH'); ?>
<?php echo csrf_field(); ?>
<h2>Vital</h2>
<div style="margin:20px;">
<div class="form-group">
    <label for="nombre">Id</label>
    <input type="text" class="form-control" name="id"  value="<?php echo e($vital->id); ?>"  readonly="readonly">
    
  </div>
  <div class="form-group">
    <label for="nombre">altura</label>
    <input type="text" class="form-control" name="altura" placeholder="Altura" value="<?php echo e($vital->altura); ?>">
    
  </div>
  <div class="form-group">
    <label for="nombre">peso</label>
    <input type="text" class="form-control" name="peso" placeholder="Peso" value="<?php echo e($vital->peso); ?>">
    
  </div>
  <div class="form-group">
    <label for="nombre">RH</label>
    <input type="text" class="form-control" name="rh" placeholder="RH" value="<?php echo e($vital->rh); ?>">
    
  </div>
  <div class="form-group">
    <label for="nombre">edad</label>
    <input type="text" class="form-control" name="edad" placeholder="edad" value="<?php echo e($vital->edad); ?>">
    
  </div>

  <div class="form-group">
    <label for="nombre">id hitoria clinica</label>
    <input type="text" class="form-control" name="id_hc"  value="<?php echo e($vital->id_hc); ?>" readonly="readonly">
    
  </div>

  
  
  
  <button type="submit" class="btn btn-primary">Actualizar</button>
  <a href="<?php echo e(route('doctores.index')); ?>"><button type="button" class="btn btn-danger">Cancelar</button></a>
  </div>
</form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\clinica1\resources\views/vitals/edit.blade.php ENDPATH**/ ?>