<?php $__env->startSection('content'); ?>
<?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>
<div style="max-width:600px;margin:0 auto; " class="mt-5 mb-5 card">

<form action="<?php echo e(route('problemas.update', $problema->id)); ?>" method="POST">
<?php echo method_field('PATCH'); ?>
<?php echo csrf_field(); ?>
<h2>Problemas</h2>
<div style="margin:20px;">
<div class="form-group">
    <label for="nombre">Id</label>
    <input type="text" class="form-control" name="id"  value="<?php echo e($problema->id); ?>"  readonly="readonly">
    
    

<div class="form-group">
  <label for="nombre">Problema</label>
  <input type="text" class="form-control" name="problema" placeholder="problema" value="<?php echo e($problema->enfermedad); ?>">
  
</div>
<div class="form-group">
  <label for="nombre">descripcion</label>
  <input type="text" class="form-control" name="descripcion" placeholder="descripcion" value="<?php echo e($problema->descripcion); ?>">
  
</div>

  <div class="form-group">
    <label for="nombre">id hitoria clinica</label>
    <input type="text" class="form-control" name="id_hc"  value="<?php echo e($problema->id_hc); ?>" readonly="readonly">
    
  </div>

  
  
  
  <button type="submit" class="btn btn-primary">Actualizar</button>
  <a href="<?php echo e(route('doctores.index')); ?>"><button type="button" class="btn btn-danger">Cancelar</button></a>
  </div>
</form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\clinica1\resources\views/problemas/edit.blade.php ENDPATH**/ ?>