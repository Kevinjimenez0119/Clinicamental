<?php $__env->startSection('content'); ?>

<table class="table">
<h2>Lista de doctores <a href="<?php echo e(route('usuarios.create')); ?>"><button type="button" class="btn btn-primary float-right" >Agregar nuevo doctor</button></a></h2>
  <thead>
    <tr>
      <th scope="col">ID</th>
      <th scope="col">NOMBRE</th>
      <th scope="col">APELLIDOS</th>
      <th scope="col">EMAIL</th>
      <th scope="col">GENERO</th>
      <th scope="col">TELEFONO</th>
      <th scope="col">HORARIO</th>
      
    </tr>
  </thead>
        <tbody>
        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      
             <tr>
                 <th scope="row"><?php echo e($user->id); ?></th>
                 <td><?php echo e($user->name); ?></td>
                 <td><?php echo e($user->apellidos); ?></td>
                 <td><?php echo e($user->email); ?></td>
                 <td><?php echo e($user->genero); ?></td>
                 <td><?php echo e($user->telefono); ?></td>
                 <td><?php echo e($user->horario); ?></td>
                 <td>
                 
                <form action="<?php echo e(route('usuarios.destroy', $user->id)); ?>" method="POST">
                <a href="<?php echo e(route('usuarios.show', $user->id)); ?>"><button type="button" class="btn btn-secondary">Ver</button></a>
                 <a href="<?php echo e(route('usuarios.edit', $user->id)); ?>"><button type="button" class="btn btn-warning">Editar</button></a>
                <?php echo method_field('DELETE'); ?>
                <?php echo csrf_field(); ?>
                <button type="submit" class="btn btn-danger">Eliminar</button>
                </form></td>
               </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  
       </tbody>
</table>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\clinica1\resources\views/usuarios/index.blade.php ENDPATH**/ ?>