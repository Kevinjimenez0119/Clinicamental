<?php $__env->startSection('content'); ?>

<div class="jumbotron jumbotron-fluid">
  <div class="container">
  <?php $__currentLoopData = $tratamientos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tratamiento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <p class="lead">Id: <?php echo e($tratamiento->id); ?></p>
  <p class="lead">Tratamiento: <?php echo e($tratamiento->tipo_tratamiento); ?></p>
  <p class="lead">Diagnostico: <?php echo e($tratamiento->diagnostico); ?></p>
  <p class="lead">Guia: <?php echo e(nlbr($tratamiento->guia)); ?></p>
  <p class="lead">Medicamentos: <?php echo e($tratamiento->medicamentos); ?></p>
  
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  <a href="<?php echo e(route('doctores.index')); ?>"><button type="button" class="btn btn-danger">Atras</button></a>
  </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app3', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\clinica1\resources\views/vitals/show.blade.php ENDPATH**/ ?>