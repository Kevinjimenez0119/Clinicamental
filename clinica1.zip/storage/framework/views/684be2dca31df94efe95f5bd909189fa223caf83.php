<?php $__env->startSection('content'); ?>

<table class="table">
<h2>Lista de pacientes <a href="<?php echo e(route('doctores.create')); ?>"><button type="button" class="btn btn-primary float-right" >Agregar nuevo paciente</button></a></h2>
  <thead>
    <tr>
      <th scope="col">ID</th>
      <th scope="col">NOMBRE</th>
      <th scope="col">APELLIDOS</th>
      <th scope="col">EMAIL</th>
      <th scope="col">GENERO</th>
      <th scope="col">OCUPACION</th>
      
    </tr>
  </thead>
        <tbody>
        <?php $__currentLoopData = $pacientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $paciente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      
             <tr>
                 <th scope="row"><?php echo e($paciente->identificacion); ?></th>
                 <td><?php echo e($paciente->name); ?></td>
                 <td><?php echo e($paciente->apellidos); ?></td>
                 <td><?php echo e($paciente->email); ?></td>
                 <td><?php echo e($paciente->genero); ?></td>
                 <td><?php echo e($paciente->ocupacion); ?></td>
                 <td>
                 
               
                <a href="<?php echo e(route('doctores.show', $paciente->identificacion)); ?>"><button type="button" class="btn btn-secondary">Ver HC</button></a>
                 <a href="<?php echo e(route('doctores.edit', $paciente->identificacion)); ?>"><button type="button" class="btn btn-warning">Editar</button></a>
                 <a href="<?php echo e(route('historias.edit', $paciente->identificacion)); ?>"><button type="button" class="btn btn-warning">Iniciar HC</button></a>
                 <a href="<?php echo e(route('traslados.edit', $paciente->identificacion)); ?>"><button type="button" class="btn btn-warning">Trasladar paciente</button></a>
                
               </td>
               </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  
       </tbody>
</table>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app3', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\clinica1\resources\views/doctores/index.blade.php ENDPATH**/ ?>