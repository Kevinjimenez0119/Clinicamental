<?php $__env->startSection('content'); ?>
<div style="max-width:600px;margin:0 auto; " class="mt-5 mb-5 card">

<form action="<?php echo e(route('traslados.update', $paciente->identificacion)); ?>" method="POST">
<?php echo method_field('PATCH'); ?>
<?php echo csrf_field(); ?>
<div style="margin:20px;">
<div class="form-group">
    <label for="nombre">Identificacion paciente</label>
    <input type="text" class="form-control"  name="id_paciente" value="<?php echo e($paciente->identificacion); ?>" readonly="readonly">
    
  </div>

  <div class="form-group">
    <label for="nombre">Nombres</label>
    <input type="text" class="form-control" name="name" value="<?php echo e($paciente->name); ?>" readonly="readonly">
    
  </div>
  <div class="form-group">
    <label for="nombre">Identificacion doctor ant</label>
    <input type="text" class="form-control" name="id_doctor_ant"  value="<?php echo e(auth()->user()->id); ?>" readonly="readonly">
    
  </div>
  <div class="form-group">
    <label for="nombre">Nombre doctor ant </label>
    <input type="text" class="form-control" name="name_doc" value="<?php echo e(auth()->user()->name); ?>" readonly="readonly">
    
    </div>
    <div class="form-group">
    <label for="email">Identificacion doctor actual</label>
    <select name="id_doctor_act" class="form-control" id="rol">
    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <option value="<?php echo e($user->id); ?>"><?php echo e($user->id); ?>, <?php echo e($user->name); ?> <?php echo e($user->apellidos); ?></option>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
    
  </div>
  
  
  
  
  <button type="submit" class="btn btn-primary">Trasladar</button>
  <a href="<?php echo e(route('doctores.index')); ?>"><button type="button" class="btn btn-danger">Cancelar</button></a>
  </div>
</form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\clinica1\resources\views/traslados/edit.blade.php ENDPATH**/ ?>