<?php $__env->startSection('content'); ?>

<table class="table">
<h2>Lista de traslados </h2>
  <thead>
    <tr>
      <th scope="col">ID</th>
      <th scope="col">Id paciente</th>
      <th scope="col">Nombre paciente</th>
      <th scope="col">Id doctor anterior</th>
      <th scope="col">Nombre doctor ant</th>
      <th scope="col">Id doctor actual</th>
      
      
    </tr>
  </thead>
        <tbody>
        <?php $__currentLoopData = $traslados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $traslado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      
             <tr>
                 <th scope="row"><?php echo e($traslado->id); ?></th>
                 <td><?php echo e($traslado->id_paciente); ?></td>
                 <td><?php echo e($traslado->nombre_paciente); ?></td>
                 <td><?php echo e($traslado->id_doctor_ant); ?></td>
                 <td><?php echo e($traslado->nombre_doctor_ant); ?></td>
                 <td><?php echo e($traslado->id_doctor_act); ?></td>
                 <td><?php echo e($traslado->created_at); ?></td>
                 
               </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  
       </tbody>
</table>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\clinica1\resources\views/traslados/index.blade.php ENDPATH**/ ?>