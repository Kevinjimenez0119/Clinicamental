<?php $__env->startSection('content'); ?>

<div class="jumbotron jumbotron-fluid">
  <div class="container">
  <?php $__currentLoopData = $historiaclinicas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $historiaclinica): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <p class="lead">Id: <?php echo e($historiaclinica->id); ?></p>
  <p class="lead">Medicamentos: <?php echo e($historiaclinica->medicamentos); ?></p>
  <p class="lead">Notas: <?php echo e($historiaclinica->notas); ?></p>
  <p class="lead">F-Creación: <?php echo e($historiaclinica->created_at); ?></p>
  <p class="lead">F-Actualización: <?php echo e($historiaclinica->updated_at); ?></p>
  <p class="lead">Id Doctor: <?php echo e(auth()->user()->identificacion); ?></p>
  <p class="lead">Nombre doctor: <?php echo e(auth()->user()->name); ?></p>
  <a href="<?php echo e(route('vps.show', $historiaclinica->id)); ?>"><button type="button" class="btn btn-secondary">Ver Vital, Problemas </button></a>
  <a href="<?php echo e(route('sintomas.show', $historiaclinica->id)); ?>"><button type="button" class="btn btn-secondary">Ver Sintomas </button></a>
  <a href="<?php echo e(route('vps.edit', $historiaclinica->id)); ?>"><button type="button" class="btn btn-warning">Editar HC</button></a>
  <a href="<?php echo e(route('vitals.show', $historiaclinica->id_tratamiento)); ?>"><button type="button" class="btn btn-success">Ver tratamiento y guia</button></a>
  

  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  <a href="<?php echo e(route('doctores.index')); ?>"><button type="button" class="btn btn-danger">Atras</button></a>
  </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app3', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\clinica1\resources\views/doctores/show.blade.php ENDPATH**/ ?>