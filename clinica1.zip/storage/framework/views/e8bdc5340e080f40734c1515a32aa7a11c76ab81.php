<?php $__env->startSection('content'); ?>


<div >
            <h5 ><strong>TABLA DE pacientes</strong> </h5>
            <a href="<?php echo e(route('usuarios.index')); ?>"><button type="button" class="btn btn-primary float-left" >ATRAS</button></a>
            <table class="table table-striped text-center">
            <a href="<?php echo e(route('pdf.index')); ?>"><button type="button" class="btn btn-primary float-right" >Generar reporte en PDF</button></a>
                <thead>
                    <tr>
                    <th >ID</th>
                    <th >NOMBRE</th>
                    <th >APELLIDOS</th>
                    <th >EMAIL</th>
                    <th >GENERO</th>
                    <th >OCUPACION</th>
                    </tr>
                </thead>
               <tbody>
               <?php $__currentLoopData = $pacientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $paciente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
               <tr>
              
                 <th ><?php echo e($paciente->identificacion); ?></th>
                 <td><?php echo e($paciente->name); ?></td>
                 <td><?php echo e($paciente->apellidos); ?></td>
                 <td><?php echo e($paciente->email); ?></td>
                 <td><?php echo e($paciente->genero); ?></td>
                 <td><?php echo e($paciente->ocupacion); ?></td>
                 
                 
               
                
                
                
               
               </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\clinica1\resources\views/reportes/index.blade.php ENDPATH**/ ?>